use mydb;

-- Total Runs Per Ininings --
select inning,sum(total_runs)as total_score from deliveries
group by inning;

SELECT * FROM mydb.deliveries;

-- overs according wickets --

select overs, count(*) as wickets
from deliveries
where is_wicket = 1
group by overs;

-- better perfomance --

select batter,sum(batsman_runs) as total_runs
from deliveries
group by batter
order by total_runs desc;

-- strike rate --

select batter,
	sum(batsman_runs)as runs,
    count(*) as balls,
    (sum(batsman_runs)/count(*))*100 as strike_rate
    from deliveries
    group by batter;
    
-- power play --

select sum(total_runs) as PowerPlay_Runs
from deliveries
where overs between 1 and 6;

-- deth over --

select sum(total_runs) as DethOver_Runs
from deliveries
where overs between 16 and 20;

-- total 4s --
select count(*) from deliveries
where batsman_runs = 4;

-- total 6s --
select count(*) from deliveries
where batsman_runs = 6;

-- most runs in single over -- 

select inning , overs , sum(total_runs) as runs_in_overs
from deliveries
group by inning , overs
order by runs_in_overs desc;

-- total balls by 1st innings --

select sum(ball) as total_runs
from deliveries
where inning = 1;

-- extra runs by all innings --

select sum(extra_runs) as Extra_Runs
from deliveries;